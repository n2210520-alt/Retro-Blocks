package com.example.retroblocks

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.graphics.*
import android.view.MotionEvent
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        setContentView(GameView())
    }

    inner class GameView : View(this) {
        val cols=10; val rows=20
        var board=Array(rows){IntArray(cols)}
        var shape=0; var rot=0; var px=3; var py=0
        var next=Random.nextInt(7); var score=0; var lines=0; var level=1
        var last=System.currentTimeMillis(); var over=false
        val shapes=arrayOf(
            arrayOf("1111"), arrayOf("100","111"), arrayOf("001","111"),
            arrayOf("11","11"), arrayOf("011","110"), arrayOf("010","111"), arrayOf("110","011")
        )
        val colors=intArrayOf(Color.CYAN,Color.BLUE,Color.rgb(255,150,20),Color.YELLOW,
            Color.GREEN,Color.rgb(180,60,230),Color.RED)
        val buttons=ArrayList<RectF>()

        init { setBackgroundColor(Color.BLACK); postInvalidateDelayed(16) }

        fun cells(s:Int=shape,r:Int=rot):List<Pair<Int,Int>> {
            var a=shapes[s].map{it.map{c->c=='1'}.toBooleanArray()}
            repeat(r%4){ a=List(a[0].size){x->BooleanArray(a.size){y->a[a.size-1-y][x]}} }
            val out=ArrayList<Pair<Int,Int>>()
            for(y in a.indices) for(x in a[y].indices) if(a[y][x]) out.add(x to y)
            return out
        }
        fun ok(nx:Int=px,ny:Int=py,nr:Int=rot):Boolean {
            for((x,y) in cells(shape,nr)){ val X=nx+x; val Y=ny+y
                if(X<0||X>=cols||Y>=rows||(Y>=0&&board[Y][X]!=0)) return false }
            return true
        }
        fun spawn(){ shape=next; next=Random.nextInt(7); rot=0; px=3; py=0; if(!ok()) over=true }
        fun lock(){
            for((x,y) in cells()){ val X=px+x; val Y=py+y; if(Y in 0 until rows) board[Y][X]=colors[shape] }
            var y=rows-1; var n=0
            while(y>=0){ if(board[y].all{it!=0}){ for(j in y downTo 1) board[j]=board[j-1].clone(); board[0]=IntArray(cols); n++ } else y-- }
            if(n>0){ lines+=n; score += intArrayOf(0,100,300,500,800)[n]*level; level=lines/10+1 }
            spawn()
        }
        fun reset(){ board=Array(rows){IntArray(cols)}; score=0; lines=0; level=1; over=false; next=Random.nextInt(7); spawn() }
        override fun onDraw(c:Canvas){
            val w=width.toFloat(); val h=height.toFloat(); val cell=minOf(w*.62f/cols,h*.82f/rows)
            val ox=(w-cell*cols)/2f; val oy=20f
            c.drawColor(Color.BLACK)
            val p=Paint(); p.style=Paint.Style.STROKE; p.color=Color.DKGRAY
            for(y in 0 until rows) for(x in 0 until cols) c.drawRect(ox+x*cell,oy+y*cell,ox+(x+1)*cell,oy+(y+1)*cell,p)
            p.style=Paint.Style.FILL
            for(y in 0 until rows) for(x in 0 until cols) if(board[y][x]!=0){p.color=board[y][x]; c.drawRect(ox+x*cell,oy+y*cell,ox+(x+1)*cell-2,oy+(y+1)*cell-2,p)}
            if(!over){p.color=colors[shape]; for((x,y) in cells()) c.drawRect(ox+(px+x)*cell,oy+(py+y)*cell,ox+(px+x+1)*cell-2,oy+(py+y+1)*cell-2,p)}
            p.color=Color.WHITE; p.textSize=32f; p.typeface=Typeface.MONOSPACE
            val sx=ox+cols*cell+18; c.drawText("RETRO",sx,55f,p); c.drawText("BLOCKS",sx,88f,p)
            p.textSize=22f; c.drawText("SCORE $score",sx,130f,p); c.drawText("LINES $lines",sx,160f,p); c.drawText("LEVEL $level",sx,190f,p)
            p.textSize=18f; c.drawText("NEXT",sx,230f,p)
            p.color=colors[next]; for((x,y) in cells(next,0)) c.drawRect(sx+x*18,245+y*18,sx+(x+1)*18-2,245+(y+1)*18-2,p)
            buttons.clear(); val by=h-125
            fun btn(x:Float,y:Float,ww:Float,hh:Float,t:String){val r=RectF(x,y,x+ww,y+hh); buttons.add(r);p.style=Paint.Style.STROKE;p.color=Color.WHITE;c.drawRect(r,p);p.style=Paint.Style.FILL;p.textSize=18f;c.drawText(t,r.left+10,r.top+29,p)}
            val bw=70f; btn(15f,by,bw,55f,"LEFT"); btn(95f,by,bw,55f,"RIGHT"); btn(175f,by,bw,55f,"TURN"); btn(255f,by,bw,55f,"DOWN"); btn(335f,by,bw,55f,"DROP")
            if(over){p.textSize=34f;c.drawText("GAME OVER",ox+10,oy+cell*9,p);p.textSize=20f;c.drawText("TAP RESTART",ox+25,oy+cell*10+30,p)}
            last=last
            if(!over && System.currentTimeMillis()-last>maxOf(90,650-(level-1)*55)){last=System.currentTimeMillis();if(ok(ny=py+1))py++ else lock()}
            postInvalidateDelayed(16)
        }
        override fun onTouchEvent(e:MotionEvent):Boolean{
            if(e.action!=MotionEvent.ACTION_DOWN) return true
            val x=e.x; val y=e.y
            if(over){reset();return true}
            when(buttons.indexOfFirst{it.contains(x,y)}){0->if(ok(nx=px-1))px--;1->if(ok(nx=px+1))px++;2->if(ok(nr=rot+1))rot++;3->if(ok(ny=py+1))py++ else lock();4->{while(ok(ny=py+1))py++;lock()}}
            return true
        }
    }
}
